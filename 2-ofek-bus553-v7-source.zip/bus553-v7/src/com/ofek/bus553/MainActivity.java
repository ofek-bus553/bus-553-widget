package com.ofek.bus553;
import android.app.*; import android.os.*; import android.Manifest; import android.content.pm.PackageManager; import android.widget.*; import android.content.*; import android.view.*;
public class MainActivity extends Activity {
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);findViewById(R.id.allow).setOnClickListener(new View.OnClickListener(){public void onClick(View v){if(Build.VERSION.SDK_INT>=23)requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},44);else refresh();}});updatePermission();}
 protected void onResume(){super.onResume();updatePermission();}
 public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);updatePermission();if(r==44)refresh();}
 private void updatePermission(){boolean ok=checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED||checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;TextView i=(TextView)findViewById(R.id.info);Button b=(Button)findViewById(R.id.allow);if(ok){i.setText("המיקום אושר ✓\n\nכדי להוסיף את הווידג׳ט: לחיצה ארוכה במסך הבית ← וידג׳טים ← קו 553");b.setVisibility(View.GONE);}else{i.setText("האפליקציה משתמשת במיקום כדי לבחור כיוון. אשר מיקום ואז הוסף את הווידג׳ט ממסך הבית.");b.setVisibility(View.VISIBLE);}}
 private void refresh(){sendBroadcast(new Intent(this,BusWidgetProvider.class).setAction(BusWidgetProvider.ACTION_REFRESH));}
}
