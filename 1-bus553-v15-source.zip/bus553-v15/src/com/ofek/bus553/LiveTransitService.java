package com.ofek.bus553;
import android.app.*; import android.content.*; import android.content.pm.ServiceInfo; import android.os.*; import java.text.*; import java.util.*; import java.util.concurrent.*;
public class LiveTransitService extends Service {
 static final String CHANNEL="live_transit", ACTION_STOP="com.ofek.bus553.STOP_LIVE"; static final int ID=55315;
 ScheduledExecutorService worker; volatile boolean stopped=false;
 public void onCreate(){super.onCreate();createChannel();startNow(notification("מתחבר לנתוני זמן אמת…","קו 553 · שנקר → עבודה"));worker=Executors.newSingleThreadScheduledExecutor();worker.scheduleWithFixedDelay(new Runnable(){public void run(){update();}},0,60,TimeUnit.SECONDS);}
 public int onStartCommand(Intent i,int flags,int id){if(i!=null&&ACTION_STOP.equals(i.getAction())){stopSelf();return START_NOT_STICKY;}return START_STICKY;}
 void startNow(Notification n){if(Build.VERSION.SDK_INT>=34)startForeground(ID,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);else startForeground(ID,n);}
 void update(){if(stopped)return;try{String body=BusWidgetProvider.get("https://curlbus.app/32260","32260");String eta=BusWidgetProvider.etaLine(body,"553",3);String stamp=new SimpleDateFormat("HH:mm",Locale.forLanguageTag("he")).format(new Date());notify(notification(eta,"553 משנקר לעבודה · חי · עודכן "+stamp));}catch(Exception e){notify(notification("אין כרגע חיבור לנתונים החיים","ניסיון נוסף בעוד דקה · לחיצה לפתיחת האפליקציה"));}}
 Notification notification(String big,String small){Intent open=new Intent(this,MainActivity.class);PendingIntent content=PendingIntent.getActivity(this,51,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Intent stop=new Intent(this,LiveTransitService.class).setAction(ACTION_STOP);PendingIntent stopPi=PendingIntent.getService(this,52,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);return new Notification.Builder(this,CHANNEL).setSmallIcon(R.drawable.ic_bus).setContentTitle("תחב״צ חי").setContentText(big).setStyle(new Notification.BigTextStyle().bigText(big+"\n"+small)).setSubText(small).setContentIntent(content).addAction(0,"הפסקה",stopPi).setOngoing(true).setOnlyAlertOnce(true).setCategory(Notification.CATEGORY_SERVICE).setVisibility(Notification.VISIBILITY_PUBLIC).build();}
 void notify(Notification n){((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(ID,n);}
 void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"זמני תחבורה חיים",NotificationManager.IMPORTANCE_LOW);c.setDescription("התראה קבועה לזמני הגעה חיים");c.setShowBadge(false);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
 public void onDestroy(){stopped=true;if(worker!=null)worker.shutdownNow();stopForeground(true);super.onDestroy();}
 public android.os.IBinder onBind(Intent i){return null;}
}
